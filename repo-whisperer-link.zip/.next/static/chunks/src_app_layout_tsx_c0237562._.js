(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__bec94160._.css",
  "static/chunks/node_modules_fd2dc817._.js",
  "static/chunks/src_b63bc3a6._.js"
],
    source: "dynamic"
});
